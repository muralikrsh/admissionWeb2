/* 1:  */ package campus;
/* 2:  */ 
/* 3:  */ public class Utils
/* 4:  */ {
/* 5:  */   public static String nullToString(String paramString)
/* 6:  */   {
/* 7:6 */     return paramString == null ? "" : paramString;
/* 8:  */   }
/* 9:  */ }


/* Location:           C:\Tomcat 7.0\webapps\admissionWeb2\WEB-INF\classes\
 * Qualified Name:     campus.Utils
 * JD-Core Version:    0.7.0.1
 */